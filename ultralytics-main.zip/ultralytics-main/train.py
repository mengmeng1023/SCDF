import warnings

warnings.filterwarnings('ignore')
from ultralytics import YOLO

if __name__ == '__main__':
    model = YOLO(r'ultralytics\cfg\models\11\yolo11n-SCDF.yaml')  # YOLO(r'D:\yolo\yolov11\ultralytics-main\datasets\yolo11.yaml')
    model.train(data=r'ultralytics/cfg/datasets/Anti-UAV-dataset.yaml', #  r'D:\yolo\yolov11\ultralytics-main\datasets\data.yaml'
                cache=False,
                imgsz=640,
                epochs=100,
                single_cls=False,  # 是否是单类别检测
                batch=8,
                close_mosaic=10,
                workers=4,
                device=0,
                optimizer='SGD',
                amp=True,
                project='runs/train',
                name='exp',
                )